package com.curatorsol.cucumber.web.zreusables;

import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.webdriver.DriverSource;

public class reusableOperations extends PageObject{

	public int GLOBAL_TIMEOUT = 60;
		
	public void typeInElement(WebElementFacade webElement, String textToType) {
		try {
			wait(webElement);
			clickOn(webElement);
			typeInto(webElement,textToType);
		} catch (Exception e) {
			
		}
	}
	
	public void wait(WebElementFacade webElement) {
		WebDriverWait wait = new WebDriverWait(getDriver(),GLOBAL_TIMEOUT);
		wait.until(ExpectedConditions.visibilityOf(webElement));
	}
	
}
