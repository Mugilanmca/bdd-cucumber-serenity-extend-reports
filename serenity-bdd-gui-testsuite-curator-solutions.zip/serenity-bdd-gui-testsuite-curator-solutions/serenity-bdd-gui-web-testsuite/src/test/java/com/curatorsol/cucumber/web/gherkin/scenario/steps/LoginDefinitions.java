package com.curatorsol.cucumber.web.gherkin.scenario.steps;

import net.thucydides.core.annotations.Steps;

import com.curatorsol.cucumber.web.steps.AccountCreation_steps;
import com.curatorsol.cucumber.web.steps.Login_Steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginDefinitions extends Login_Steps {
	
	@Steps
	AccountCreation_steps objAccountCreationSteps;
	
	@Given("a user launch the browser with Curator application URL")
	public void a_user_launch_the_browser_with_Curator_application_URL() {
		launchURL();
	}

	@When("a user enters {string} and {string} and then click the submit button")
	public void a_user_enters_and_and_then_click_the_submit_button(String userName, String password) throws Exception {
		enterLoginDetails(userName, password);
		clickSubmitButton();
	}

	@When("user click the Account link and enter account information like {string},{string}, {string},{string},{string} and {string} in the account section")
	public void user_click_the_Account_link_and_enter_account_information_like_and_in_the_account_section(String acname, String adminfname, String adminlname, String acemail, String acphone, String actpackage) {
		objAccountCreationSteps.clickOnAccountTab();
		objAccountCreationSteps.clickOnAddAccountTab();
		objAccountCreationSteps.enterAccountName(acname);
		objAccountCreationSteps.enterFirstName(adminfname);
		objAccountCreationSteps.enterLastName(adminlname);
		objAccountCreationSteps.enterEmail(acemail);
		objAccountCreationSteps.enterPhoneNumber(acphone);
		objAccountCreationSteps.enterAccountPackage(actpackage);
		objAccountCreationSteps.clickOnCreateAccountButton();
	}
	
	@Then("user should able to create Account successfully completed")
	public void user_should_able_to_create_Account_successfully_completed() {
		String alertmsg = objAccountCreationSteps.confirmmsg.getText();
		if(alertmsg.contains("The account was created.")) 
		{
		System.out.println("Account was created Successfully");
		}
	}
	
	@When("title of login page is Free CRM")
	public void title_of_login_page_is_Free_CRM() {
		getLoginCRMTitle("#1 Free CRM for Any Business: Online Customer Relationship Software");
	}

	@Then("user enters {string} and {string}")
	public void user_enters_and(String username, String password) throws InterruptedException {
		clickLoginButton();
		Thread.sleep(2000);
		enterLoginDetails(username, password);
	  
	}

	@Then("user clicks on login button")
	public void user_clicks_on_login_button() throws InterruptedException {
		clickSubmitButton();
	}

	@Then("user is on home page")
	public void user_is_on_home_page() {
	//	getHomeTitle("CRMPRO");
	}

	@Then("Close the browser")
	public void close_the_browser() {
		closeBrowser();
	   
	}
	


}
