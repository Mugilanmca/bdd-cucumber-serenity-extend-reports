package com.curatorsol.cucumber.web.zobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.curatorsol.cucumber.web.zreusables.reusable;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class LoginPage extends PageObject{
	
	WebDriver driver = null;
		
	@FindBy(xpath="//a[text()='Log In']")
	public WebElementFacade btnLogin;
	
	@FindBy(id="username")
	public WebElementFacade txtUsername;
	
	@FindBy(id="password")
	public WebElementFacade txtPassword;
	
	@FindBy(id="_submit")
	public WebElementFacade btnSubmit;
	
	
	
	
	
	
	public void clickOnSubmit()
	{
		btnSubmit.click();
	}
	
	public void enterUserName(String username)
	{
		txtUsername.sendKeys(username);
		clickOn(txtUsername);
	}
	
	public void enterPassword(String password)
	{
		txtPassword.sendKeys(password);
	}
	
	public String getLoginCRMTitle()
	{
		String title = getDriver().getTitle();
		
		return title;
	}
	
	public String getHomeTitle()
	{
		String title = getDriver().getTitle();
		
		return title;
	}
	
	public void clickLoginButton()
	{
		btnLogin.click();
	}
}