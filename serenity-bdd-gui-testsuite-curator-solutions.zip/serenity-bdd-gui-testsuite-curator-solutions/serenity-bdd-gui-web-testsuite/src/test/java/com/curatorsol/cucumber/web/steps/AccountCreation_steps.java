package com.curatorsol.cucumber.web.steps;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.curatorsol.cucumber.web.zobjects.AccountCreationPage;
import com.curatorsol.cucumber.web.zobjects.LoginPage;
import com.curatorsol.cucumber.web.zreusables.reusable;

import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class AccountCreation_steps extends AccountCreationPage {

	LoginPage objLoginPage;
	reusable objResuable = new reusable();
	public final static String Framework_specifications_property_path = "testproperties/";
	public final static String Application_url_property_file = "globalSettings.properties";

	public void clickOnAccountTab()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		clickOn(accountTab);
	}
	
	

	public void clickOnAddAccountTab()
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		clickOn(addaccountbtn);
	}

	public void enterAccountName(String username)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		actname.sendKeys(username);
		clickOn(actname);
	}
	
	public void enterFirstName(String adminfname)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		adminfirstname.sendKeys(adminfname);
		clickOn(adminfirstname);
	}
	
	public void enterLastName(String adminlname)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		adminlastname.sendKeys(adminlname);
		clickOn(adminlastname);
	}

	public void enterEmail(String acemail)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		adminemail.sendKeys(acemail);
		clickOn(adminemail);
	}
	
	public void enterPhoneNumber(String acphone)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		adminphoneno.sendKeys(acphone);
		clickOn(adminphoneno);
	}

	public void enterAccountPackage(String actpackage)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		actpkgid.sendKeys(actpackage);
		clickOn(actpkgid);
	}

	public void clickOnCreateAccountButton() {
		clickOn(crtactbtn);
	
}
	
	
}
