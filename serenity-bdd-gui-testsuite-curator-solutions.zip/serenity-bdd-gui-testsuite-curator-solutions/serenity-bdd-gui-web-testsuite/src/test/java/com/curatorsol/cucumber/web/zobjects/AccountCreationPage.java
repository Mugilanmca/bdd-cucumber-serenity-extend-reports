package com.curatorsol.cucumber.web.zobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class AccountCreationPage extends PageObject{
	
	@FindBy(xpath= "//a[@data-target='#accountmenuitems']")
	public WebElementFacade accountTab;
	
	@FindBy(xpath = "//a[contains(text(),'Add Account')]")
	public WebElementFacade addaccountbtn;
	
	@FindBy(id= "account_name")
	public WebElementFacade actname;
	
	@FindBy(id= "account_admin_firstname")
	public WebElementFacade adminfirstname;
	
	@FindBy(id= "account_admin_lastname")
	public WebElementFacade adminlastname;
	
	@FindBy(id= "account_admin_email")
	public WebElementFacade adminemail;
	
	@FindBy(id= "account_phone_number")
	public WebElementFacade adminphoneno;
	
	@FindBy(id= "account_package_id")
	public WebElementFacade actpkgid;
	
	@FindBy(xpath= "//button[@class='btn btn-create-module']")
	public WebElementFacade crtactbtn;
	
	@FindBy(xpath= "//div[@class='alert alert-success alert-dismissable']")
	public WebElementFacade confirmmsg;
	
	//Add license button
	@FindBy(xpath="//a[@class='init-tooltip pull-right btn-create-module']")
	public WebElementFacade Addlicense;
	//package selection
	@FindBy(id = "license_package_id")
	public WebElementFacade Packageid;
	
	//organization objects
	@FindBy(id = "license_university_name")
	public WebElementFacade orgName;
	
	@FindBy(id="license_university_organizationType")
	public WebElementFacade orgType;
	
	@FindBy(id="license_university_url")
	public WebElementFacade orgWebsite;
	
	@FindBy(id="license_university_acronym")
	public WebElementFacade orgAcronym;
	
	@FindBy(id="license_university_defContentLang")
	public WebElementFacade orgDefaultContentLanguage;
	
	@FindBy(id="btnUniversitySubmit")
	public WebElementFacade licCreateBtn;
	
	//license creation confirmation message
	@FindBy(xpath="//div[@class='alert alert-success alert-dismissable']")
	public WebElementFacade licconfirmmsg;

}
