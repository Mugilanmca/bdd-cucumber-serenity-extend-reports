package com.curatorsol.cucumber.web.steps;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import com.curatorsol.cucumber.web.zobjects.LoginPage;
import com.curatorsol.cucumber.web.zreusables.reusable;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class Login_Steps extends LoginPage {

	LoginPage objLoginPage;
	reusable objResuable = new reusable();
	public final static String Framework_specifications_property_path = "testproperties/";
	public final static String Application_url_property_file = "globalSettings.properties";

	@Step
	public void enterLoginDetails(String userName, String password) throws InterruptedException {

		enterUserName(userName);
		//typeInto(objLoginPage.txtUsername,userName);
		Thread.sleep(1000);
		objLoginPage.enterPassword(password);
	}

	@Step
	public void clickSubmitButton() throws InterruptedException {

		objLoginPage.clickOnSubmit();
		Thread.sleep(2000);
	}

	@Step
	public void getLoginCRMTitle(String expectedTitle) {
		String title = objLoginPage.getLoginCRMTitle();
		//assertEquals(title, expectedTitle);
	}

	@Step
	public void getHomeTitle(String expectedTitle) {
		String title = objLoginPage.getHomeTitle();
		//assertEquals(title, expectedTitle);
	}

	@Step
	public void launchURL() {
	//	String appurl = objResuable.readProperty(Application_url_property_file, "url");
	//	getDriver().get(appurl);
		getDriver().get("https://elearis-test.shyftcloud.com/login");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@Step
	public void getUrl() {
		String appurl = objResuable.readProperty(Application_url_property_file,
				"url");
		getDriver().get(appurl);
	}
	
	public void closeBrowser(){
		getDriver().quit();
		
	}
	
	public void clickLoginButton()
	{
		objLoginPage.clickLoginButton();
	}
}
